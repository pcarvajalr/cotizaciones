import { Macro } from './macro';

export const MACROS : Macro[] = [
    {
        id:1,
        nombre: 'Rosales Torre 1'
    },
    {
        id:2,
        nombre: 'Rosales Torre 2'
    },
    {
        id:3,
        nombre: 'Atlantis Torre 1'
    },
    {
        id:4,
        nombre: 'Atlantis Torre 2'
    },
    {
        id:5,
        nombre: 'Astromelias Conjunto'
    }
];