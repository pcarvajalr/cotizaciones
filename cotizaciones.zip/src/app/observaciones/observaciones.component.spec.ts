import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ObservacionesComponent } from './observaciones.component';
import { By } from '@angular/platform-browser';
import { Macro } from '../macro';
import { DebugElement } from '@angular/core';

describe('ObservacionesComponent', () => {
  let component: ObservacionesComponent;
  let fixture: ComponentFixture<ObservacionesComponent>;
  let macrosMock: Macro[];

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ObservacionesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ObservacionesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('debe existir un "div" de clase "row"',()=>{
    const divRow = fixture.debugElement.query(By.css('div[class="row"]'));
    expect(divRow).toBeTruthy();
  });

  it('deberia existir un "div" con la clase "col-md-1"', ()=>{
    const divCol = fixture.debugElement.query(By.css('div[class="col-md-1"]'));
    expect(divCol).toBeTruthy();
  });

  it('deberia existir un "select" con nombre "selMacro"',()=>{
    const selMacro = fixture.debugElement.query(By.css('select[name="selMacro"]'));
    expect(selMacro).toBeTruthy();
  });

  it('deberian existir tantos "option" como tantos elementos existan en el arreglo "MacroProyectos"', () => {
    let macros: Macro[];
    component.macros$.subscribe((macrosResultantes)=>{
      macros = macrosResultantes;
    });
    const optionMacros = fixture.debugElement.queryAll(By.css("option"));
    expect(optionMacros.length).toBe(macros.length);
  });

  it('deberia los "option" contener el valor de la propiedad "nombre" del arreglo "macros"', () => {
    const optionMacros = fixture.debugElement.queryAll(By.css('option[class="optionMacros"]')
    );

    optionMacros.forEach(function (heroeAc: DebugElement, index: number) {
      const heroeElement: HTMLElement = heroeAc.nativeElement;
      expect(heroeElement.textContent).toContain(
        macrosMock[index].id.toString() && macrosMock[index].nombre
      );
    });
  });
});
