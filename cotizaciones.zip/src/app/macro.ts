export class Macro {
    id: number;
    nombre: string;
}